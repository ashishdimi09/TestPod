//
//  ICAppDelegate.h
//  IMIconnectCoreSDK
//
//  Created by Jeremy Oddos on 11/07/2016.
//  Copyright © 2016 IMImobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UserNotifications/UserNotifications.h>

NS_ASSUME_NONNULL_BEGIN

@interface ICAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

#pragma mark - Initialisation

/**
 * Initialises the SDK, reading configuration from the configuration file (IMIconnectConfiguration.plist). 
 * Moreover, if push notifications are enabled for the app, this method will register the app to use them.
 * @param application the current application
 * @param launchOptions the launch options of the app
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(nullable NSDictionary *)launchOptions;

#pragma mark - Application state

/**
 * Disconnects the RTM connection when the app enters background mode
 * @param application the current application
 */
- (void)applicationDidEnterBackground:(UIApplication *)application;

/**
 * Reconnects the RTM connection when the app enters foreground mode
 * @param application the current application
 */
- (void)applicationWillEnterForeground:(UIApplication *)application;

#ifdef __IPHONE_8_0

#pragma mark - Actions

/**
 * Handles the action that the user has selected from a local notification.
 * A nil action identifier indicates the default action.
 * @param application the current application
 * @param identifier the identifier of the action
 * @param notification the notification containing the selected action
 * @param responseInfo the responseInfo containing the user's response
 * @param completionHandler a completionHandler that will be called as soon as the action has been handled
 */
- (void)application:(UIApplication *)application handleActionWithIdentifier:(nullable NSString *)identifier forLocalNotification:(UILocalNotification *)notification withResponseInfo:(NSDictionary *)responseInfo completionHandler:(void(^)())completionHandler;
- (void)application:(UIApplication *)application handleActionWithIdentifier:(nullable NSString *)identifier forLocalNotification:(UILocalNotification *)notification completionHandler:(void(^)())completionHandler;

/**
 * Handles the action that the user has selected from a remote notification.
 * A nil action identifier indicates the default action.
 * @param application the current application
 * @param identifier the identifier of the action
 * @param userInfo the notification containing the selected action
 * @param responseInfo the responseInfo containing the user's response
 * @param completionHandler a completionHandler that will be called as soon as the action has been handled
 */
- (void)application:(UIApplication *)application handleActionWithIdentifier:(nullable NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo withResponseInfo:(NSDictionary *)responseInfo completionHandler:(void(^)())completionHandler;
- (void)application:(UIApplication *)application handleActionWithIdentifier:(nullable NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler;
/**
* iOS 10.0+
*/
// For handling push in background
// The method will be called on the delegate when the user responded to the notification by opening the application, dismissing the notification or choosing a UNNotificationAction. The delegate must be set before the application returns from application:didFinishLaunchingWithOptions:.
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler;

// For handling push in foreground
// The method will be called on the delegate only if the application is in the foreground. If the method is not implemented or the handler is not called in a timely manner then the notification will not be presented. The application can choose to have the notification presented as a sound, badge, alert and/or in the notification list. This decision should be based on whether the information in the notification is otherwise visible to the user.
- (void)userNotificationCenter:(UNUserNotificationCenter *)center
       willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler;
#pragma mark - Notification registration

/**
 * Registers notification settings for the app
 * The settings granted to the application will be passed in as the second argument.
 * @param application the current application
 * @param notificationSettings The settings granted for the application
 */
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings;

#endif

/**
 * Registers the deviceToken which is needed to receive remote notifications
 * @param application The current application
 * @param deviceToken the deviceToken generated by Apple to receive remote notifications
 */
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;

/**
 * Logs the failure of notification registration
 * @param application The current application
 * @param error the error to be logged
 */
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error;

#pragma mark - Remote notification

/**
 * Handles the received remote notification
 * @param application the current application
 * @param userInfo the content of the received remote notification
 * @param completionHandler A completionHandler that will be called as soon as the handling process is done
 */
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo;

#pragma mark - Local notification

/**
 * Handles the received local notification
 * @param application the current application
 * @param notification the content of the received local notification
 */
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification;

#pragma mark - Wake up in background

/**
 * Applications with the "fetch" background mode may be given opportunities to fetch updated content in the background or when it is convenient for the system.
 * This method should be called in those situations.
 * @param application The current application
 * @param completionHandler completionHandler is called as soon as the SDK finished performing the operations.
 */
- (void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;

@end

NS_ASSUME_NONNULL_END
