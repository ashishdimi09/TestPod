//
//  ICPreferences.h
//  IMIconnectCoreSDK
//
//  Created by Bala obul reddy sangana on 11/08/20.
//  Copyright © 2020 IMImobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ICPreferences : NSObject

/**
 * Saves a key-value pair in the preferences
 * @param key a key that will be stored associated to a value
 * @param value a value that will be stored associated to a key
 * @return YES if the pair has been successfully stored, NO otherwise
 */
+ (BOOL)saveArrayPreferenceWithKey:(NSString *)key andValue:(NSArray *)value;

/**
 * Loads preferences from an associated key
 * @param key the preference key
 * @return the preference value
 */
+ (NSArray *)loadArrayPreferenceWithKey:(NSString *)key;

/**
 * Removes preferences from an associated key
 * @param key the preference key
 * @return YES if the pair has been successfully removed, NO otherwise
 */
+ (BOOL)removePreferenceWithKey:(NSString *)key;


@end

