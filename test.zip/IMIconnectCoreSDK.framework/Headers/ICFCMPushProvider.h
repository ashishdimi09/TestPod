//
//  ICFcmPushProvider.h
//  IMIconnectCoreSDK
//
//  Created by Ashish Das on 29/01/20.
//  Copyright © 2020 IMImobile. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ICFCMPushProvider <NSObject>

- (NSString *)getToken;

- (void) subscribeToTopic:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable error))completionHandler;

- (void) unsubscribeFromTopic:(NSString *)topic;

@end

NS_ASSUME_NONNULL_END
