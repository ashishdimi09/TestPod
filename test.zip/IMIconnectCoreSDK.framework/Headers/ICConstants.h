//
//  ICConstants.h
//  IMIconnectCoreSDK
//
//  Created by Naresh Nallamsetty on 09/12/19.
//  Copyright © 2019 IMImobile. All rights reserved.
//

#ifndef ICConstants_h
#define ICConstants_h
#define KEY_CONNECT_MESSAGE @"icmessage"
#define BUNDLE_EXTRA_APP_USER_ID @"ic_app_user_id"
#endif /* ICConstants_h */
