//
//  ICInAppModalNotificationViewStyle.h
//  IMIconnectCoreSDK
//
//  Created by Umesh Naidu Challa on 10/04/19.
//  Copyright © 2019 IMImobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ICInAppNotificationViewStyle.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ICInAppModalNotificationViewStyle : ICInAppNotificationViewStyle

@end

NS_ASSUME_NONNULL_END
