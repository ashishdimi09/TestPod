//
//  ICEnvironment.h
//  IMIconnectCoreSDKFramework
//
//  Created by Bala obul reddy sangana on 05/11/20.
//  Copyright © 2020 IMImobile. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    ICEnvironmentUK,
    ICEnvironmentUS,
    ICEnvironmentCA,
    ICEnvironmentIN,
    ICEnvironmentTC,
    ICEnvironmentAzureUS
} ICEnvironment;


@interface ICServerEnvironment : NSObject

+ (ICEnvironment)getEnumFromString:(NSString *)environment;

@end

