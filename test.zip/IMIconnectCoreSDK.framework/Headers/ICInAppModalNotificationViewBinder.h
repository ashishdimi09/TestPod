//
//  ICInAppModalNotificationViewBinder.h
//  IMIconnectCoreSDK
//
//  Created by Umesh Naidu Challa on 03/01/19.
//  Copyright © 2019 IMImobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICInAppNotificationViewBinder.h"

NS_ASSUME_NONNULL_BEGIN

@interface ICInAppModalNotificationViewBinder : ICInAppNotificationViewBinder

@end

NS_ASSUME_NONNULL_END
