//
//  AshishPodTest.h
//  TestPod
//
//  Created by Ashish Das on 03/03/21.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface AshishPodTest : NSObject

- (void) showAlertMsg:(UIViewController *)viewController title:(NSString *)title message:(NSString *)message;

@end
